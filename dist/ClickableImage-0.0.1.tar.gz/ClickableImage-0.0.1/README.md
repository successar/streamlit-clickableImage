# streamlit-texthighlighter

Install: `pip install https://raw.githubusercontent.com/successar/streamlit-clickableImage/main/dist/ClickableImage-0.0.1-py3-none-any.whl`
